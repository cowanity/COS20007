﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SwinAdventure
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create an item
            Item sword = new Item(new string[] { "sword" }, "bronze sword", "This is a mighty fine sword.");

            // Create a player
            Player player = new Player("Fred", "the mighty programmer");

            // Add the sword to the player's inventory
            player.Inventory.Put(sword);

            // Test locating objects
            GameObject foundObject1 = player.Locate("me");
            GameObject foundObject2 = player.Locate("sword");

            if (foundObject1 != null)
            {
                Console.WriteLine(foundObject1.FullDescription);
            }

            if (foundObject2 != null)
            {
                Console.WriteLine(foundObject2.FullDescription);
            }
        }
    }
}
