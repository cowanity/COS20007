﻿using System;
using NUnit.Framework;
using SwinAdventure;

namespace IdentifiableObject
{
    public class ItemTests
    {
        [Test]
        public void ItemIsIdentifiable()
        {
            Item item = new Item(new string[] { "sword" }, "bronze sword", "This is a mighty fine sword.");

            Assert.IsTrue(item.AreYou("sword"), "Item should respond to 'sword'");
            Assert.IsFalse(item.AreYou("axe"), "Item should not respond to 'axe'");
        }

        [Test]
        public void ShortDescriptionReturnsCorrectString()
        {
            Item item = new Item(new string[] { "sword" }, "bronze sword", "This is a mighty fine sword.");

            Assert.That(item.ShortDescription, Is.EqualTo("a bronze sword (sword)"));
        }

        [Test]
        public void FullDescriptionReturnsItemDescription()
        {
            Item item = new Item(new string[] { "sword" }, "bronze sword", "This is a mighty fine sword.");

            Assert.That(item.FullDescription, Is.EqualTo("This is a mighty fine sword."));
        }
    }

}

