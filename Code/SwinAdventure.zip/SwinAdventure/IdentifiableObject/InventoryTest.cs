﻿using System;
using NUnit.Framework;

namespace IdentifiableObject
{
    using NUnit.Framework;
    using SwinAdventure;

    [TestFixture]
    public class InventoryTests
    {
        [Test]
        public void FindItemInInventory()
        {
            Inventory inventory = new Inventory();
            Item item = new Item(new string[] { "shovel" }, "a shovel", "A gardening shovel.");

            inventory.Put(item);

            Assert.IsTrue(inventory.HasItem("shovel"), "Inventory should have 'shovel'");
        }

        [Test]
        public void NoItemFoundInEmptyInventory()
        {
            Inventory inventory = new Inventory();

            Assert.IsFalse(inventory.HasItem("axe"), "Inventory should not have 'axe'");
        }

        [Test]
        public void FetchItemFromInventory()
        {
            Inventory inventory = new Inventory();
            Item item = new Item(new string[] { "shovel" }, "a shovel", "A gardening shovel.");
            inventory.Put(item);

            Item fetchedItem = inventory.Fetch("shovel");

            Assert.IsNotNull(fetchedItem, "Inventory should fetch 'shovel'");
            Assert.IsTrue(fetchedItem.AreYou("shovel"), "Fetched item should be 'shovel'");
            Assert.IsTrue(inventory.HasItem("shovel"), "Item should remain in inventory");
        }

        [Test]
        public void TakeItemFromInventory()
        {
            Inventory inventory = new Inventory();
            Item item = new Item(new string[] { "shovel" }, "a shovel", "A gardening shovel.");
            inventory.Put(item);

            Item takenItem = inventory.Take("shovel");

            Assert.IsNotNull(takenItem, "Inventory should take 'shovel'");
            Assert.IsTrue(takenItem.AreYou("shovel"), "Taken item should be 'shovel'");
            Assert.IsFalse(inventory.HasItem("shovel"), "Item should be removed from inventory");
        }

        [Test]
        public void ItemListReturnsMultipleLines()
        {
            Inventory inventory = new Inventory();
            Item item1 = new Item(new string[] { "shovel" }, "a shovel", "A gardening shovel.");
            Item item2 = new Item(new string[] { "sword" }, "a sword", "A sharp sword.");
            inventory.Put(item1);
            inventory.Put(item2);

            string itemList = inventory.ItemList;

            Assert.IsTrue(itemList.Contains("a shovel (shovel)"), "Item list should contain 'a shovel'");
            Assert.IsTrue(itemList.Contains("a sword (sword)"), "Item list should contain 'a sword'");
        }
    }
}