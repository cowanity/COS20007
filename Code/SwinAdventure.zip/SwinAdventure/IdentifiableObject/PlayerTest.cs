﻿using System;
using NUnit.Framework;

namespace IdentifiableObject
{
    using NUnit.Framework;
    using SwinAdventure;

    [TestFixture]
    public class PlayerTests
    {
        [Test]
        public void PlayerIsIdentifiable()
        {
            Player player = new Player("Fred", "the mighty programmer");

            Assert.IsTrue(player.AreYou("me"), "Player should respond to 'me'");
            Assert.IsTrue(player.AreYou("inventory"), "Player should respond to 'inventory'");
            Assert.IsFalse(player.AreYou("player"), "Player should not respond to 'player'");
        }

        [Test]
        public void PlayerLocatesItemsInInventory()
        {
            Player player = new Player("Fred", "the mighty programmer");
            Item item = new Item(new string[] { "sword" }, "bronze sword", "This is a mighty fine sword.");
            player.Inventory.Put(item);

            GameObject locatedItem = player.Locate("sword");

            Assert.IsNotNull(locatedItem, "Player should locate 'sword'");
            Assert.IsTrue(locatedItem.AreYou("sword"), "Located item should be 'sword'");
            Assert.IsTrue(player.Inventory.HasItem("sword"), "Item should remain in player's inventory");
        }

        [Test]
        public void PlayerLocatesItself()
        {
            Player player = new Player("Fred", "the mighty programmer");

            GameObject locatedPlayer1 = player.Locate("me");
            GameObject locatedPlayer2 = player.Locate("inventory");

            Assert.IsNotNull(locatedPlayer1, "Player should locate 'me'");
            Assert.IsTrue(locatedPlayer1.AreYou("me"), "Located object should be 'me'");
            Assert.IsNotNull(locatedPlayer2, "Player should locate 'inventory'");
            Assert.IsTrue(locatedPlayer2.AreYou("inventory"), "Located object should be 'inventory'");
        }

        [Test]
        public void PlayerLocatesNothing()
        {
            Player player = new Player("Fred", "the mighty programmer");

            GameObject locatedObject = player.Locate("axe");

            Assert.IsNull(locatedObject, "Player should not locate 'axe'");
        }

        [Test]
        public void PlayerFullDescriptionContainsItems()
        {
            Player player = new Player("Fred", "the mighty programmer");
            Item item1 = new Item(new string[] { "shovel" }, "a shovel", "A gardening shovel.");
            Item item2 = new Item(new string[] { "sword" }, "a sword", "A sharp sword.");
            player.Inventory.Put(item1);
            player.Inventory.Put(item2);

            string fullDescription = player.FullDescription;

            Assert.IsTrue(fullDescription.Contains("You are Fred, the mighty programmer."), "FullDescription should contain player's name and description");
            Assert.IsTrue(fullDescription.Contains("You are carrying:"), "FullDescription should contain 'You are carrying:'");
            Assert.IsTrue(fullDescription.Contains("a shovel (shovel)"), "FullDescription should contain 'a shovel'");
            Assert.IsTrue(fullDescription.Contains("a sword (sword)"), "FullDescription should contain 'a sword'");
        }
    }
}
