﻿using NUnit.Framework;

namespace SwinAdventure
{
    [TestFixture]
    public class IdentifiableObjectTest
    {
        private IdentifiableObject _testObject;
        private IdentifiableObject _testObject_emp;

        [SetUp]
        public void Setup()
        {
            _testObject = new IdentifiableObject(new string[] { "fred", "mark" });
            _testObject_emp = new IdentifiableObject(new string[] { });
        }

        [Test]
        public void TestAreYou()
        {
            Assert.That(_testObject.AreYou("fred"), Is.True);
        }

        [Test]
        public void TestNotAreYou()
        {
            Assert.That(_testObject.AreYou("wilma"), Is.False);
        }

        [Test]
        public void Insensitive()
        {
            Assert.That(_testObject.AreYou("FRED"), Is.True);
        }

        [Test]
        public void TestFirstIdFred()
        {
            Assert.That(_testObject.FirstId, Is.EqualTo("fred"));
        }

        [Test]
        public void TestFirstIdMark()
        {
            Assert.That(_testObject.FirstId, Is.Not.EqualTo("mark"));
        }

        [Test]
        public void TestFirstIdWithNoId()
        {
            Assert.That(_testObject_emp.FirstId, Is.EqualTo(""));
        }

        [Test]
        public void TestAddID()
        {
            _testObject_emp.AddIdentifier("wilma");
            Assert.That(_testObject_emp.AreYou("WILMA"), Is.True);
        }
    }
}
